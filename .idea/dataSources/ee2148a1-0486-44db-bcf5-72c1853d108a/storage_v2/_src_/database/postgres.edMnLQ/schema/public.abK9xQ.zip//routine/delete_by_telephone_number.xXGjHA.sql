create procedure delete_by_telephone_number(IN phone_number integer)
    language plpgsql
as
$$
    begin
        delete from phonebook where telephone_number = phone_number;
    end
    $$;

alter procedure delete_by_telephone_number(integer) owner to postgres;

