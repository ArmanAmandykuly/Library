create procedure delete_by_telephone_number(IN phone_number character varying)
    language plpgsql
as
$$
    begin
        delete from phonebook where telephone_number = phone_number;
    end
    $$;

alter procedure delete_by_telephone_number(varchar) owner to postgres;

