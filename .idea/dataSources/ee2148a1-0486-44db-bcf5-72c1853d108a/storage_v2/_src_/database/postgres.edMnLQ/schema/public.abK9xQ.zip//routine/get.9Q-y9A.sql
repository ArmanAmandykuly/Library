create function get(ind1 integer, ind2 integer) returns SETOF phonebook
    language plpgsql
as
$$
    begin
        return query select * from phonebook limit ind2-ind1 offset ind1;
    end;
    $$;

alter function get(integer, integer) owner to postgres;

