create function username_pattern_match(p character varying) returns SETOF phonebook
    language plpgsql
as
$$
    begin
        return query select * from phonebook where username like p;
    end
    $$;

alter function username_pattern_match(varchar) owner to postgres;

