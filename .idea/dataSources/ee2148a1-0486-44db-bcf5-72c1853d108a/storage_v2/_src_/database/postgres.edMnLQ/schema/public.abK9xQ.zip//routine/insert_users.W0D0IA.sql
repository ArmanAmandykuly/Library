create procedure insert_users(IN usernames character varying[], IN telephone_numbers character varying[])
    language plpgsql
as
$$
    begin
        for i in 1..array_length(usernames, 1)
        loop
            if telephone_numbers[i] not like '8%' then
                raise notice 'telephone_number = %, username = %', telephone_numbers[i], usernames[i];
            else
                call insert_user(usernames[i], telephone_numbers[i]);
            end if;
        end loop;
    end
    $$;

alter procedure insert_users(character varying[], character varying[]) owner to postgres;

