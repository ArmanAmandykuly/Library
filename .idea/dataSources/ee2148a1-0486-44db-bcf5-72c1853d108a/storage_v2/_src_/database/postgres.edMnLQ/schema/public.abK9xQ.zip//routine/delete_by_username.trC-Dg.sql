create procedure delete_by_username(IN name character varying)
    language plpgsql
as
$$
    begin
        delete from phonebook where username = name;
    end
    $$;

alter procedure delete_by_username(varchar) owner to postgres;

