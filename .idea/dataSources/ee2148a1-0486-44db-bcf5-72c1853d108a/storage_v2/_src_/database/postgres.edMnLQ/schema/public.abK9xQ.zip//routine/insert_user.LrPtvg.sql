create procedure insert_user(IN var_username character varying, IN phone_number character varying)
    language plpgsql
as
$$
    begin
        if (select username from phonebook where username = var_username) isnull
        then
            insert into phonebook values(var_username, phone_number);
        else
            update phonebook set telephone_number = phone_number
            where username = var_username;
        end if;
    end
    $$;

alter procedure insert_user(varchar, varchar) owner to postgres;

